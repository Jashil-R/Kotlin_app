import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class ExpensesActivity : AppCompatActivity() {

    private lateinit var dateInput: EditText
    private lateinit var timeInput: EditText
    private lateinit var amountInput: EditText
    private lateinit var categoryInput: EditText
    private lateinit var pictureButton: Button
    private lateinit var cancelButton: Button
    private lateinit var addButton: Button

    private val PICK_IMAGE_REQUEST = 1002
    private var imageUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.expenseactivity) // Update with your layout name

        // Initialize views
        dateInput = findViewById(R.id.dateInput)
        timeInput = findViewById(R.id.timeInput)
        amountInput = findViewById(R.id.amountInput)
        categoryInput = findViewById(R.id.categoryInput)
        pictureButton = findViewById(R.id.pictureButton)
        cancelButton = findViewById(R.id.cancelButton)
        addButton = findViewById(R.id.addButton)

        // Date picker
        dateInput.setOnClickListener {
            val c = Calendar.getInstance()
            DatePickerDialog(this, { _, year, month, day ->
                dateInput.setText("$year-${month + 1}-$day")
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
        }

        // Time picker
        timeInput.setOnClickListener {
            val c = Calendar.getInstance()
            TimePickerDialog(this, { _, hour, minute ->
                timeInput.setText(String.format("%02d:%02d", hour, minute))
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
        }

        // Picture button opens gallery
        pictureButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(intent, PICK_IMAGE_REQUEST)
        }

        // Cancel button
        cancelButton.setOnClickListener {
            finish()
        }

        // Add button
        addButton.setOnClickListener {
            val date = dateInput.text.toString()
            val time = timeInput.text.toString()
            val amount = amountInput.text.toString()
            val category = categoryInput.text.toString()

            Toast.makeText(this, "Expense Added: $category - $amount", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            imageUri = data.data
            Toast.makeText(this, "Image selected", Toast.LENGTH_SHORT).show()
        }
    }
}
