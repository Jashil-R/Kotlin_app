import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MonthlyGoalsActivity : AppCompatActivity() {

    private lateinit var minGoalInput: EditText
    private lateinit var maxGoalInput: EditText
    private lateinit var cancelButton: Button
    private lateinit var saveButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.monthlygoalsactivity) // Match this to your XML filename

        // Initialize views
        minGoalInput = findViewById(R.id.minGoalInput)
        maxGoalInput = findViewById(R.id.maxGoalInput)
        cancelButton = findViewById(R.id.cancelButton)
        saveButton = findViewById(R.id.saveButton)

        // Cancel button closes activity
        cancelButton.setOnClickListener {
            finish()
        }

        // Save button validates and shows toast
        saveButton.setOnClickListener {
            val minGoal = minGoalInput.text.toString()
            val maxGoal = maxGoalInput.text.toString()

            if (minGoal.isNotEmpty() && maxGoal.isNotEmpty()) {
                Toast.makeText(this, "Goals saved: Min $minGoal, Max $maxGoal", Toast.LENGTH_SHORT).show()
                // Optionally: Save to database or SharedPreferences here
            } else {
                Toast.makeText(this, "Please enter both goals", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
